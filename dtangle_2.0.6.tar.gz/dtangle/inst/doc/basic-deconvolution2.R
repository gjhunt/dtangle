## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ------------------------------------------------------------------------
library('dtangle')
names(shen_orr_ex)

## ------------------------------------------------------------------------
head(shen_orr_ex$annotation$mixture)

## ------------------------------------------------------------------------
Y <- shen_orr_ex$data$log
Y[1:4,1:4]

## ------------------------------------------------------------------------
?dtangle2

## ------------------------------------------------------------------------
library('dtangle')
data = shen_orr_ex$data$log
mixture_proportions = shen_orr_ex$annotation$mixture

## ------------------------------------------------------------------------
mixture_proportions

## ------------------------------------------------------------------------
pure_samples = list(Liver=c(1,2,3),Brain=c(4,5,6),Lung=c(7,8,9))

dt_out = dtangle2(Y=data, pure_samples = pure_samples)

## ------------------------------------------------------------------------
true_proportions = mixture_proportions[-(1:9),]
matplot(true_proportions,dt_out$estimates, xlim = c(0,1),ylim=c(0,1),xlab="Truth",ylab="Estimates")

## ------------------------------------------------------------------------
mixture_samples = data[-(1:9),]
reference_samples = data[1:9,]

dt_out = dtangle2(Y=mixture_samples, reference=reference_samples,pure_samples = pure_samples)

matplot(true_proportions,dt_out$estimates, xlim = c(0,1),ylim=c(0,1),xlab="Truth",ylab="Estimates")

## ------------------------------------------------------------------------
ref_reduced = t(sapply(pure_samples,function(x)colMeans(reference_samples[x,,drop=FALSE])))

dt_out = dtangle2(Y=mixture_samples, reference=ref_reduced)

matplot(true_proportions,dt_out$estimates, xlim = c(0,1),ylim=c(0,1),xlab="Truth",ylab="Estimates")

## ------------------------------------------------------------------------
dt_out = dtangle2(Y=mixture_samples, references = ref_reduced)

## ------------------------------------------------------------------------
dt_out = dtangle2(Y=mixture_samples, references = ref_reduced,marker_method = "diff")

## ------------------------------------------------------------------------
dt_out$n_markers

## ------------------------------------------------------------------------
dt_out = dtangle2(Y=mixture_samples, references = ref_reduced,marker_method = "diff",n_markers=100)

dt_out$n_markers

## ------------------------------------------------------------------------
dt_out = dtangle2(Y=mixture_samples, references = ref_reduced,marker_method = "diff",n_markers=c(100,150,50))

dt_out$n_markers

## ------------------------------------------------------------------------
dt_out = dtangle2(Y=mixture_samples, references = ref_reduced,marker_method = "diff",n_markers=.075)

dt_out$n_markers

dt_out = dtangle2(Y=mixture_samples, references = ref_reduced,marker_method = "diff",n_markers=c(.1,.15,.05))

dt_out$n_markers

## ------------------------------------------------------------------------
marker_genes = list(c(120,253,316),
                    c(180,429,14),
                    c(1,109,206))

dt_out = dtangle2(Y=mixture_samples, references = ref_reduced,markers=marker_genes)
dt_out$n_markers

## ------------------------------------------------------------------------
mrkrs = find_markers(Y=mixture_samples, references = ref_reduced)
names(mrkrs)

## ------------------------------------------------------------------------
dt_out = dtangle2(Y = mixture_samples,references = ref_reduced,markers=mrkrs,n_markers=.1)

## ------------------------------------------------------------------------
lin_scale_mix = 2^mixture_samples
lin_scale_ref = 2^ref_reduced

## ------------------------------------------------------------------------
dt_out = dtangle2(Y=lin_scale_mix,references = lin_scale_ref,inv_scale = base::identity,
                  seed=1234,markers = mrkrs$L)
head(dt_out$estimates)

## ------------------------------------------------------------------------
ahs_scale_mix = asinh(lin_scale_mix)
ahs_scale_ref = asinh(lin_scale_ref)

dt_out = dtangle2(Y=ahs_scale_mix,references = ahs_scale_ref,inv_scale = base::sinh,
                  seed=1234,markers = mrkrs$L)
head(dt_out$estimates)

